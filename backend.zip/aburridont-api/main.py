"""
AburridoNT API — Agente IA + CRM + Webhooks
Conectado a Supabase como fuente de datos.
"""
import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.routers import agente, webhooks, crm

app = FastAPI(
    title="AburridoNT API",
    version="2.0.0",
    description="Backend: Agente IA para WhatsApp/Instagram + CRM",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(agente.router, prefix="/api/agente", tags=["Agente IA"])
app.include_router(webhooks.router, prefix="/api/webhooks", tags=["Webhooks"])
app.include_router(crm.router, prefix="/api/crm", tags=["CRM"])


@app.get("/")
def root():
    return {"status": "ok", "app": "AburridoNT API v2.0"}


@app.get("/health")
def health():
    return {"status": "healthy"}
