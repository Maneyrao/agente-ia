"""
Servicio del Agente IA.
Recibe mensaje → arma contexto desde Supabase → llama a Claude → responde.
"""
import os
import json
import httpx
from app.services.supabase import query, insert, update

CLAUDE_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")
CLAUDE_MODEL = "claude-sonnet-4-5-20250929"

NIVELES = [
    "PRE A1 STARTER", "PRE A1 STARTER +", "A1 MOVERS", "A1 YOUNGEST",
    "A2 FLYERS", "A0", "A1", "A2", "B1", "B1 UPPER", "B2",
    "SPEAKING INICIAL", "SPEAKING INT", "SPEAKING AVANZADO", "TALLER",
]

SYSTEM_PROMPT = """Sos el asistente virtual de AburridoNT (@aburridont.clases), un instituto de inglés 100% virtual.

Tu rol: Atender consultas de potenciales alumnos, asesorar sobre cursos, y gestionar inscripciones.

INFORMACIÓN DEL INSTITUTO:
- Clases 100% virtuales por Zoom, grupales (máx 4 alumnos) e individuales
- Niveles disponibles: {niveles}
- Precio grupal nuevos: $80.000–$85.000/mes (2hs semanales)
- Speaking Club (entrada): $40.000–$50.000/mes
- Individuales: desde $90.000/mes

HORARIOS DISPONIBLES:
{horarios}

INSTRUCCIONES:
1. Sé amable, cercano, usá español rioplatense natural
2. Preguntá nombre y edad/nivel del alumno
3. Recomendá nivel y horario apropiado según disponibilidad
4. Si está interesado, pedí WhatsApp para coordinar
5. Si no hay horario, ofrecé lista de espera
6. No inventes horarios que no están en la lista

Cuando necesites ejecutar una acción, incluí al final:
{{"accion": "clasificar_lead|inscribir|seguimiento", "datos": {{...}}}}

HISTORIAL:
{historial}"""


async def _build_horarios() -> str:
    """Construye texto de horarios desde Supabase."""
    docentes = await query("docentes", "?es_owner=eq.false&activo=eq.true&order=id")
    grupos = await query("grupos", "?activo=eq.true&order=id")
    horarios = await query("grupo_horarios", "?order=grupo_id")
    alumnos = await query("alumnos", "?estado=eq.activo&order=id")
    disponibilidad = await query("disponibilidad", "?disponible=eq.true&order=docente_id")

    lines = []
    for doc in docentes:
        did = doc["id"]
        doc_grupos = [g for g in grupos if g["docente_id"] == did]

        # Occupied slots
        occupied = set()
        for g in doc_grupos:
            g_horarios = [h for h in horarios if h["grupo_id"] == g["id"]]
            for h in g_horarios:
                occupied.add(f"{h['dia']}|{h['hora']}")

        # Available slots
        doc_disp = [d for d in disponibilidad if d["docente_id"] == did]
        available = []
        for d in doc_disp:
            key = f"{d['dia']}|{d['hora']}"
            if key not in occupied:
                available.append(f"  - {d['dia']} {d['hora']}")

        # Groups info
        groups_text = []
        for g in doc_grupos:
            g_horarios = [h for h in horarios if h["grupo_id"] == g["id"]]
            g_alumnos = [a for a in alumnos if a.get("grupo_id") == g["id"]]
            slots_str = ", ".join(
                f"{h['dia'][:3]} {h['hora']}" for h in g_horarios
            )
            groups_text.append(
                f"  * {g['nombre']} ({g['nivel']}) — {slots_str} — "
                f"{len(g_alumnos)}/{g['capacidad_max']} alumnos"
            )

        lines.append(f"\n{doc['nombre']}:")
        if groups_text:
            lines.append("  Grupos:\n" + "\n".join(groups_text))
        if available:
            lines.append(
                "  Horarios libres:\n" + "\n".join(available[:12])
            )
        else:
            lines.append("  Sin horarios libres")

    return "\n".join(lines) if lines else "No hay horarios cargados."


async def _get_historial(contact_id: int) -> str:
    """Últimos mensajes de un contacto."""
    msgs = await query(
        "mensajes",
        f"?contacto_id=eq.{contact_id}&order=created_at.desc&limit=10",
    )
    msgs.reverse()
    lines = []
    for m in msgs:
        role = "Alumno" if m["role"] == "user" else "Asistente"
        lines.append(f"{role}: {m['mensaje']}")
    return "\n".join(lines) if lines else "Primera conversación."


async def procesar_mensaje(
    mensaje: str,
    canal: str = "whatsapp",
    contacto_whatsapp: str = "",
    contacto_nombre: str = "",
) -> dict:
    """Procesa un mensaje y genera respuesta."""

    # 1. Find or create contact
    contactos = []
    if contacto_whatsapp:
        contactos = await query(
            "contactos", f"?whatsapp=eq.{contacto_whatsapp}"
        )

    if contactos:
        contacto = contactos[0]
    else:
        contacto = await insert("contactos", {
            "nombre": contacto_nombre or "Nuevo contacto",
            "whatsapp": contacto_whatsapp,
            "canal": canal,
            "estado": "LEAD",
        })

    if not contacto:
        return {"respuesta": "Error interno", "accion": None, "datos": None}

    cid = contacto["id"]

    # 2. Save user message
    await insert("mensajes", {
        "contacto_id": cid,
        "canal": canal,
        "role": "user",
        "mensaje": mensaje,
    })

    # 3. Build context
    horarios = await _build_horarios()
    historial = await _get_historial(cid)

    system = SYSTEM_PROMPT.format(
        niveles=", ".join(NIVELES),
        horarios=horarios,
        historial=historial,
    )

    # 4. Call Claude
    respuesta = ""
    accion = None
    datos = None

    if not CLAUDE_API_KEY:
        respuesta = (
            "¡Hola! Gracias por escribir a AburridoNT 🎓\n"
            "Somos un instituto de inglés 100% virtual. "
            "¿Buscás clases para vos o para alguien más?"
        )
    else:
        try:
            async with httpx.AsyncClient(timeout=30) as client:
                resp = await client.post(
                    "https://api.anthropic.com/v1/messages",
                    headers={
                        "x-api-key": CLAUDE_API_KEY,
                        "anthropic-version": "2023-06-01",
                        "content-type": "application/json",
                    },
                    json={
                        "model": CLAUDE_MODEL,
                        "max_tokens": 1024,
                        "system": system,
                        "messages": [{"role": "user", "content": mensaje}],
                    },
                )
                data = resp.json()
                raw = data["content"][0]["text"]

                # Extract action JSON
                respuesta = raw
                if '{"accion"' in raw:
                    try:
                        idx = raw.rindex('{"accion"')
                        parsed = json.loads(raw[idx:])
                        accion = parsed.get("accion")
                        datos = parsed.get("datos")
                        respuesta = raw[:idx].strip()
                    except (json.JSONDecodeError, ValueError):
                        pass
        except Exception as e:
            respuesta = f"Disculpá, hubo un error. ¿Podés repetir tu consulta?"

    # 5. Save response
    await insert("mensajes", {
        "contacto_id": cid,
        "canal": canal,
        "role": "assistant",
        "mensaje": respuesta,
    })

    # 6. Process action
    if accion == "clasificar_lead" and datos:
        await update("contactos", f"?id=eq.{cid}", {
            "estado": datos.get("estado", "CONSULTANDO"),
            "curso_interes": datos.get("curso_interes", ""),
        })
    elif accion == "inscribir" and datos:
        await update("contactos", f"?id=eq.{cid}", {"estado": "INSCRIPTO"})
    elif accion == "seguimiento" and datos:
        await insert("seguimientos", {
            "contacto_id": cid,
            "fecha_programada": datos.get("fecha", ""),
            "mensaje_sugerido": datos.get("mensaje", ""),
            "estado": "pendiente",
        })

    return {
        "respuesta": respuesta,
        "accion": accion,
        "datos": datos,
        "contacto_id": cid,
    }
