"""
Cliente de Supabase para el backend.
Usa httpx para hacer requests a la REST API de Supabase.
"""
import os
import httpx
from typing import Optional

SUPABASE_URL = os.getenv("SUPABASE_URL", "")
SUPABASE_KEY = os.getenv("SUPABASE_KEY", "")  # service_role key


def _headers():
    return {
        "apikey": SUPABASE_KEY,
        "Authorization": f"Bearer {SUPABASE_KEY}",
        "Content-Type": "application/json",
        "Prefer": "return=representation",
    }


async def query(table: str, params: str = "") -> list:
    """GET request to Supabase REST API."""
    async with httpx.AsyncClient() as client:
        r = await client.get(
            f"{SUPABASE_URL}/rest/v1/{table}{params}",
            headers=_headers(),
        )
        if r.status_code == 200:
            return r.json()
        return []


async def insert(table: str, data: dict) -> Optional[dict]:
    """POST (insert) to Supabase."""
    async with httpx.AsyncClient() as client:
        r = await client.post(
            f"{SUPABASE_URL}/rest/v1/{table}",
            headers=_headers(),
            json=data,
        )
        if r.status_code in (200, 201):
            result = r.json()
            return result[0] if isinstance(result, list) and result else result
        return None


async def update(table: str, params: str, data: dict) -> Optional[dict]:
    """PATCH (update) to Supabase."""
    async with httpx.AsyncClient() as client:
        r = await client.patch(
            f"{SUPABASE_URL}/rest/v1/{table}{params}",
            headers=_headers(),
            json=data,
        )
        if r.status_code == 200:
            result = r.json()
            return result[0] if isinstance(result, list) and result else result
        return None


async def rpc(function_name: str, params: dict = None):
    """Call a Supabase RPC function."""
    async with httpx.AsyncClient() as client:
        r = await client.post(
            f"{SUPABASE_URL}/rest/v1/rpc/{function_name}",
            headers=_headers(),
            json=params or {},
        )
        if r.status_code == 200:
            return r.json()
        return None
