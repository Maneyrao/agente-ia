"""
Webhooks — recibe mensajes de WhatsApp (Twilio o Meta).
Estos endpoints son los que configurás como webhook URL en tu proveedor.
"""
import os
import httpx
from fastapi import APIRouter, Request, Response, Query
from app.services.agente_service import procesar_mensaje

router = APIRouter()

# ─── TWILIO WHATSAPP ───

TWILIO_ACCOUNT_SID = os.getenv("TWILIO_ACCOUNT_SID", "")
TWILIO_AUTH_TOKEN = os.getenv("TWILIO_AUTH_TOKEN", "")
TWILIO_WA_NUMBER = os.getenv("TWILIO_WA_NUMBER", "")  # whatsapp:+14155238886


@router.post("/twilio")
async def twilio_webhook(request: Request):
    """
    Twilio envía form data con:
    - Body: texto del mensaje
    - From: whatsapp:+5411XXXXXXXX
    - To: tu número de Twilio
    """
    form = await request.form()
    body = form.get("Body", "")
    from_number = form.get("From", "").replace("whatsapp:", "")
    profile_name = form.get("ProfileName", "")

    if not body:
        return Response(content="<Response/>", media_type="application/xml")

    # Procesar con agente
    result = await procesar_mensaje(
        mensaje=body,
        canal="whatsapp",
        contacto_whatsapp=from_number,
        contacto_nombre=profile_name,
    )

    # Responder via Twilio
    if TWILIO_ACCOUNT_SID and TWILIO_AUTH_TOKEN:
        try:
            async with httpx.AsyncClient() as client:
                await client.post(
                    f"https://api.twilio.com/2010-04-01/Accounts/{TWILIO_ACCOUNT_SID}/Messages.json",
                    auth=(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN),
                    data={
                        "From": TWILIO_WA_NUMBER,
                        "To": f"whatsapp:{from_number}",
                        "Body": result["respuesta"],
                    },
                )
        except Exception as e:
            print(f"Error sending Twilio message: {e}")

    # TwiML response (fallback)
    twiml = f"<Response><Message>{result['respuesta']}</Message></Response>"
    return Response(content=twiml, media_type="application/xml")


# ─── META WHATSAPP BUSINESS API ───

META_VERIFY_TOKEN = os.getenv("WHATSAPP_VERIFY_TOKEN", "aburridont_verify_2025")
META_ACCESS_TOKEN = os.getenv("WHATSAPP_TOKEN", "")
META_PHONE_ID = os.getenv("WHATSAPP_PHONE_ID", "")


@router.get("/meta")
async def meta_verify(request: Request):
    """Meta webhook verification (GET request)."""
    mode = request.query_params.get("hub.mode")
    token = request.query_params.get("hub.verify_token")
    challenge = request.query_params.get("hub.challenge")

    if mode == "subscribe" and token == META_VERIFY_TOKEN:
        return Response(content=challenge, media_type="text/plain")
    return Response(status_code=403)


@router.post("/meta")
async def meta_webhook(request: Request):
    """
    Meta envía JSON con mensajes de WhatsApp Business.
    """
    data = await request.json()

    try:
        entry = data.get("entry", [{}])[0]
        changes = entry.get("changes", [{}])[0]
        value = changes.get("value", {})
        messages = value.get("messages", [])

        if not messages:
            return {"status": "no messages"}

        msg = messages[0]
        from_number = msg.get("from", "")
        text = msg.get("text", {}).get("body", "")

        # Get contact name
        contacts = value.get("contacts", [{}])
        profile_name = contacts[0].get("profile", {}).get("name", "") if contacts else ""

        if not text:
            return {"status": "no text"}

        # Procesar con agente
        result = await procesar_mensaje(
            mensaje=text,
            canal="whatsapp",
            contacto_whatsapp=from_number,
            contacto_nombre=profile_name,
        )

        # Enviar respuesta por Meta API
        if META_ACCESS_TOKEN and META_PHONE_ID:
            try:
                async with httpx.AsyncClient() as client:
                    await client.post(
                        f"https://graph.facebook.com/v18.0/{META_PHONE_ID}/messages",
                        headers={
                            "Authorization": f"Bearer {META_ACCESS_TOKEN}",
                            "Content-Type": "application/json",
                        },
                        json={
                            "messaging_product": "whatsapp",
                            "to": from_number,
                            "type": "text",
                            "text": {"body": result["respuesta"]},
                        },
                    )
            except Exception as e:
                print(f"Error sending Meta WA message: {e}")

        return {"status": "processed"}

    except Exception as e:
        print(f"Meta webhook error: {e}")
        return {"status": "error"}
