-- ══════════════════════════════════════════════════════════════
-- SEED DATA: Grupos, Horarios de grupo, Alumnos
-- Ejecutar DESPUÉS del schema principal
-- ══════════════════════════════════════════════════════════════

-- GRUPOS
INSERT INTO grupos (nombre, nivel, docente_id, horas_semanales, capacidad_max) VALUES
  ('A2 FLYERS', 'A2 FLYERS', 2, 4, 5),
  ('A0', 'A0', 2, 4, 5),
  ('A1 SAB', 'A1', 2, 2, 6),
  ('A1 MAR JUE', 'A1', 2, 4, 5),
  ('SPK SAB', 'SPEAKING INICIAL', 3, 1, 5),
  ('SPK V-S', 'SPEAKING INICIAL', 3, 2, 5),
  ('A2 IND Her', 'A2', 3, 1, 1),
  ('A1 IND Damian', 'A1', 3, 1, 1);

-- HORARIOS DE GRUPO
-- A2 FLYERS (id=1): Mar Jue 18:00
INSERT INTO grupo_horarios (grupo_id, dia, hora) VALUES
  (1, 'Martes', '18:00'), (1, 'Jueves', '18:00');
-- A0 (id=2): Mar Jue 20:00
INSERT INTO grupo_horarios (grupo_id, dia, hora) VALUES
  (2, 'Martes', '20:00'), (2, 'Jueves', '20:00');
-- A1 SAB (id=3): Sab 11:00, 12:00
INSERT INTO grupo_horarios (grupo_id, dia, hora) VALUES
  (3, 'Sábado', '11:00'), (3, 'Sábado', '12:00');
-- A1 MAR JUE (id=4): Mar Jue 19:00
INSERT INTO grupo_horarios (grupo_id, dia, hora) VALUES
  (4, 'Martes', '19:00'), (4, 'Jueves', '19:00');
-- SPK SAB (id=5): Sab 10:00
INSERT INTO grupo_horarios (grupo_id, dia, hora) VALUES
  (5, 'Sábado', '10:00');
-- SPK V-S (id=6): Vie 17:00, Sab 9:00
INSERT INTO grupo_horarios (grupo_id, dia, hora) VALUES
  (6, 'Viernes', '17:00'), (6, 'Sábado', '9:00');
-- A2 IND Her (id=7): Vie 18:00
INSERT INTO grupo_horarios (grupo_id, dia, hora) VALUES
  (7, 'Viernes', '18:00');
-- A1 IND Damian (id=8): Mar 9:00
INSERT INTO grupo_horarios (grupo_id, dia, hora) VALUES
  (8, 'Martes', '9:00');

-- ALUMNOS (con grupo)
INSERT INTO alumnos (nombre, apellido, nivel, docente_id, grupo_id, monto, horas_semanales, horario) VALUES
  ('Valentina', 'Rojas', 'A2 FLYERS', 2, 1, 60000, 4, 'Mar Jue 18:00'),
  ('Frida Ambar', 'Azambulla', 'A2 FLYERS', 2, 1, 60000, 4, 'Mar Jue 18:00'),
  ('Isabella', 'Raspuntin', 'A2 FLYERS', 2, 1, 60000, 4, 'Mar Jue 18:00'),
  ('Zoe', 'Velasquez', 'A0', 2, 2, 60000, 4, 'Mar Jue 20:00'),
  ('Benjamín', 'Mira', 'A0', 2, 2, 50000, 4, 'Mar Jue 20:00'),
  ('Florencia', 'Vazquez', 'A1', 2, 3, 50000, 2, 'Sab 11-13'),
  ('Kevin', 'Benítez', 'A1', 2, 3, 50000, 2, 'Sab 11-13'),
  ('Maria Fernanda', 'Colfer', 'A1', 2, 3, 55000, 2, 'Sab 11-13'),
  ('Lucia', 'Vazquez', 'A1', 2, 3, 60000, 2, 'Sab 11-13'),
  ('Alexia Belen', 'Diaz', 'A1', 2, 4, 60000, 4, 'Mar Jue 19:00'),
  ('Julia', 'Del Valle Guzmán', 'A1', 2, 4, 55000, 4, 'Mar Jue 19:00'),
  ('Antonio David', 'Re', 'A1', 2, 4, 50000, 4, 'Mar Jue 19:00'),
  ('Desiree', 'Velasquez', 'A1', 2, 4, 60000, 4, 'Mar Jue 19:00'),
  ('Angelica Ruth', 'Arancibia', 'SPEAKING INICIAL', 3, 5, 36000, 1, 'Sab 10:00'),
  ('Daniela Sofia', 'Bonetti Kunt', 'SPEAKING INICIAL', 3, 6, 60000, 2, 'Vie Sab'),
  ('Her', '', 'A2', 3, 7, 48000, 1, 'Vie 18:00'),
  ('Damian Leandro', 'Frutos', 'A1', 3, 8, 52000, 1, 'Mar 9:00');

-- ALUMNOS (individuales con Thiago)
INSERT INTO alumnos (nombre, apellido, nivel, docente_id, monto, horas_semanales, horario) VALUES
  ('Melissa', 'Algieri', 'A1', 1, 55000, 4, 'Mar Jue 20:00'),
  ('Sofi', 'Ferreyra', 'A2', 1, 50000, 4, ''),
  ('Sofia', 'Roberts', 'A2', 1, 90000, 4, ''),
  ('Marcelo', 'Sotto', 'A1', 1, 45000, 1, 'Mie 18:00'),
  ('Florencia', 'Abagnale', 'B1', 1, 88000, 4, ''),
  ('Juan Pablo', 'Moir', 'B1', 1, 75000, 2, ''),
  ('Sebastián', '', 'A1', 1, 52000, 1, ''),
  ('Valentin', 'Bramson', 'A1', 1, 60000, 2, ''),
  ('Lila', 'Bramson', 'B1', 1, 60000, 2, ''),
  ('Esteban', 'Barone', 'B1 UPPER', 1, 135000, 6, ''),
  ('Victor', '', 'B1', 1, 129000, 4, ''),
  ('Rafaela', 'Paulette', 'B1', 1, 100000, 4, ''),
  ('Asane', 'Diop', 'A1', 1, 55000, 2, ''),
  ('Soledad', 'Boytenko', 'A1', 1, 52000, 1, ''),
  ('Kevin', '', 'A2', 1, 52000, 2, ''),
  ('Alan', 'Sbaglia', 'B1', 1, 94000, 4, ''),
  ('Cristian Daniel', 'Ance', 'A2', 1, 52000, 1, ''),
  ('Ariel', 'D', 'B1', 1, 88000, 4, ''),
  ('Ezequiel', 'Rango', 'A2', 1, 55000, 4, ''),
  ('Mora', 'Puntin', 'A1', 1, 60000, 2, ''),
  ('Cami', '', 'A1', 1, 60000, 1, ''),
  ('Mariano', 'Flores Zarate', 'A1', 1, 45000, 1, '');

-- Generar pagos del mes actual para todos los activos
SELECT generar_pagos_mes(to_char(now(), 'YYYY-MM'));
