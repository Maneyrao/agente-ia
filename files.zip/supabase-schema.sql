-- ══════════════════════════════════════════════════════════════
-- ABURRIDONT — Schema completo para Supabase
-- Ejecutar en: Supabase Dashboard > SQL Editor > New Query
-- ══════════════════════════════════════════════════════════════

-- ─── 1. DOCENTES ───
CREATE TABLE docentes (
  id SERIAL PRIMARY KEY,
  nombre TEXT NOT NULL,
  es_owner BOOLEAN DEFAULT false,
  activo BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- ─── 2. TARIFAS POR DOCENTE ───
-- Cada docente tiene rangos: de X a Y alumnos → $Z/hora
CREATE TABLE tarifas (
  id SERIAL PRIMARY KEY,
  docente_id INT REFERENCES docentes(id) ON DELETE CASCADE,
  min_alumnos INT NOT NULL,
  max_alumnos INT NOT NULL,
  valor_hora INT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- ─── 3. DISPONIBILIDAD HORARIA ───
-- Cada fila = un slot de 1 hora donde el docente puede dar clase
CREATE TABLE disponibilidad (
  id SERIAL PRIMARY KEY,
  docente_id INT REFERENCES docentes(id) ON DELETE CASCADE,
  dia TEXT NOT NULL CHECK (dia IN ('Lunes','Martes','Miércoles','Jueves','Viernes','Sábado')),
  hora TEXT NOT NULL,
  disponible BOOLEAN DEFAULT true,
  UNIQUE(docente_id, dia, hora)
);

-- ─── 4. GRUPOS ───
CREATE TABLE grupos (
  id SERIAL PRIMARY KEY,
  nombre TEXT NOT NULL,
  nivel TEXT NOT NULL,
  docente_id INT REFERENCES docentes(id),
  horas_semanales NUMERIC(4,1) NOT NULL DEFAULT 2,
  capacidad_max INT NOT NULL DEFAULT 5,
  activo BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- ─── 5. HORARIOS DE GRUPO ───
-- Cada grupo tiene 1 o más slots (ej: Martes 18:00 + Jueves 18:00)
CREATE TABLE grupo_horarios (
  id SERIAL PRIMARY KEY,
  grupo_id INT REFERENCES grupos(id) ON DELETE CASCADE,
  dia TEXT NOT NULL CHECK (dia IN ('Lunes','Martes','Miércoles','Jueves','Viernes','Sábado')),
  hora TEXT NOT NULL,
  UNIQUE(grupo_id, dia, hora)
);

-- ─── 6. ALUMNOS ───
CREATE TABLE alumnos (
  id SERIAL PRIMARY KEY,
  nombre TEXT NOT NULL,
  apellido TEXT DEFAULT '',
  whatsapp TEXT DEFAULT '',
  nivel TEXT NOT NULL DEFAULT 'A1',
  docente_id INT REFERENCES docentes(id),
  grupo_id INT REFERENCES grupos(id) ON DELETE SET NULL,
  monto INT NOT NULL DEFAULT 0,
  horas_semanales NUMERIC(4,1) DEFAULT 2,
  horario TEXT DEFAULT '',
  estado TEXT NOT NULL DEFAULT 'activo' CHECK (estado IN ('activo', 'inactivo')),
  canal_ingreso TEXT DEFAULT 'manual' CHECK (canal_ingreso IN ('whatsapp','instagram','landing','manual','referido')),
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- ─── 7. PAGOS MENSUALES ───
-- Un registro por alumno por mes. Se marca pagado o no.
CREATE TABLE pagos (
  id SERIAL PRIMARY KEY,
  alumno_id INT REFERENCES alumnos(id) ON DELETE CASCADE,
  mes TEXT NOT NULL, -- formato: '2025-01', '2025-02', etc.
  monto INT NOT NULL,
  pagado BOOLEAN DEFAULT false,
  fecha_pago TIMESTAMPTZ,
  metodo TEXT DEFAULT '', -- 'transferencia', 'efectivo', 'mercadopago', etc.
  notas TEXT DEFAULT '',
  created_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(alumno_id, mes)
);

-- ─── 8. HISTORIAL DE ALTAS Y BAJAS ───
-- Se registra automáticamente con trigger
CREATE TABLE movimientos (
  id SERIAL PRIMARY KEY,
  alumno_id INT REFERENCES alumnos(id) ON DELETE CASCADE,
  tipo TEXT NOT NULL CHECK (tipo IN ('alta', 'baja', 'reactivacion')),
  mes TEXT NOT NULL,
  nombre_alumno TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- ─── 9. SNAPSHOTS MENSUALES ───
-- Foto del estado financiero de cada mes (se cierra al final del mes)
CREATE TABLE snapshots_mensuales (
  id SERIAL PRIMARY KEY,
  mes TEXT NOT NULL UNIQUE,
  alumnos_activos INT,
  alumnos_nuevos INT DEFAULT 0,
  bajas INT DEFAULT 0,
  facturacion_bruta INT,
  costo_docentes INT,
  ganancia_neta INT,
  pagaron INT DEFAULT 0,
  no_pagaron INT DEFAULT 0,
  detalle_docentes JSONB DEFAULT '[]',
  -- formato: [{"docente_id":2,"nombre":"Gianella","horas_semana":12,"costo_mensual":43000}]
  created_at TIMESTAMPTZ DEFAULT now()
);

-- ─── 10. CRM — CONTACTOS (LEADS) ───
CREATE TABLE contactos (
  id SERIAL PRIMARY KEY,
  nombre TEXT NOT NULL,
  whatsapp TEXT DEFAULT '',
  instagram TEXT DEFAULT '',
  canal TEXT DEFAULT 'whatsapp' CHECK (canal IN ('whatsapp','instagram','landing','manual')),
  estado TEXT DEFAULT 'LEAD' CHECK (estado IN ('LEAD','CONSULTANDO','INTERESADO','INSCRIPTO','NO_POR_AHORA')),
  curso_interes TEXT DEFAULT '',
  motivo_no TEXT DEFAULT '',
  alumno_id INT REFERENCES alumnos(id),
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- ─── 11. CONVERSACIONES DEL AGENTE ───
CREATE TABLE mensajes (
  id SERIAL PRIMARY KEY,
  contacto_id INT REFERENCES contactos(id) ON DELETE CASCADE,
  canal TEXT DEFAULT 'whatsapp',
  role TEXT NOT NULL CHECK (role IN ('user','assistant','system')),
  mensaje TEXT NOT NULL,
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT now()
);

-- ─── 12. SEGUIMIENTOS PROGRAMADOS ───
CREATE TABLE seguimientos (
  id SERIAL PRIMARY KEY,
  contacto_id INT REFERENCES contactos(id) ON DELETE CASCADE,
  fecha_programada TIMESTAMPTZ NOT NULL,
  mensaje_sugerido TEXT DEFAULT '',
  estado TEXT DEFAULT 'pendiente' CHECK (estado IN ('pendiente','enviado','respondido','cancelado')),
  created_at TIMESTAMPTZ DEFAULT now()
);


-- ══════════════════════════════════════════════════════════════
-- TRIGGERS: Auto-tracking de altas/bajas
-- ══════════════════════════════════════════════════════════════

-- Trigger: cuando un alumno cambia de estado, registrar movimiento
CREATE OR REPLACE FUNCTION fn_registrar_movimiento()
RETURNS TRIGGER AS $$
BEGIN
  -- Alta: nuevo alumno activo
  IF TG_OP = 'INSERT' AND NEW.estado = 'activo' THEN
    INSERT INTO movimientos (alumno_id, tipo, mes, nombre_alumno)
    VALUES (NEW.id, 'alta', to_char(now(), 'YYYY-MM'), NEW.nombre || ' ' || COALESCE(NEW.apellido, ''));
  END IF;

  -- Cambio de estado
  IF TG_OP = 'UPDATE' AND OLD.estado != NEW.estado THEN
    IF NEW.estado = 'inactivo' THEN
      INSERT INTO movimientos (alumno_id, tipo, mes, nombre_alumno)
      VALUES (NEW.id, 'baja', to_char(now(), 'YYYY-MM'), NEW.nombre || ' ' || COALESCE(NEW.apellido, ''));
    ELSIF NEW.estado = 'activo' AND OLD.estado = 'inactivo' THEN
      INSERT INTO movimientos (alumno_id, tipo, mes, nombre_alumno)
      VALUES (NEW.id, 'reactivacion', to_char(now(), 'YYYY-MM'), NEW.nombre || ' ' || COALESCE(NEW.apellido, ''));
    END IF;
  END IF;

  -- Update timestamp
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_movimiento_alumno
BEFORE INSERT OR UPDATE ON alumnos
FOR EACH ROW EXECUTE FUNCTION fn_registrar_movimiento();


-- Trigger: auto-generar registro de pago cuando se inscribe un alumno
CREATE OR REPLACE FUNCTION fn_crear_pago_mes()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.estado = 'activo' THEN
    INSERT INTO pagos (alumno_id, mes, monto, pagado)
    VALUES (NEW.id, to_char(now(), 'YYYY-MM'), NEW.monto, false)
    ON CONFLICT (alumno_id, mes) DO NOTHING;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_pago_auto
AFTER INSERT OR UPDATE OF estado ON alumnos
FOR EACH ROW EXECUTE FUNCTION fn_crear_pago_mes();


-- ══════════════════════════════════════════════════════════════
-- FUNCIÓN: Generar pagos para un mes específico
-- Uso: SELECT generar_pagos_mes('2025-04');
-- ══════════════════════════════════════════════════════════════

CREATE OR REPLACE FUNCTION generar_pagos_mes(p_mes TEXT)
RETURNS INT AS $$
DECLARE
  cnt INT := 0;
BEGIN
  INSERT INTO pagos (alumno_id, mes, monto, pagado)
  SELECT id, p_mes, monto, false
  FROM alumnos
  WHERE estado = 'activo'
  ON CONFLICT (alumno_id, mes) DO NOTHING;

  GET DIAGNOSTICS cnt = ROW_COUNT;
  RETURN cnt;
END;
$$ LANGUAGE plpgsql;


-- ══════════════════════════════════════════════════════════════
-- FUNCIÓN: Cerrar mes y crear snapshot
-- Uso: SELECT cerrar_mes('2025-03');
-- ══════════════════════════════════════════════════════════════

CREATE OR REPLACE FUNCTION cerrar_mes(p_mes TEXT)
RETURNS VOID AS $$
DECLARE
  v_activos INT;
  v_altas INT;
  v_bajas INT;
  v_bruto INT;
  v_pagaron INT;
  v_no_pagaron INT;
  v_docentes JSONB;
BEGIN
  SELECT count(*) INTO v_activos FROM alumnos WHERE estado = 'activo';
  SELECT count(*) INTO v_altas FROM movimientos WHERE mes = p_mes AND tipo IN ('alta', 'reactivacion');
  SELECT count(*) INTO v_bajas FROM movimientos WHERE mes = p_mes AND tipo = 'baja';
  SELECT COALESCE(sum(monto), 0) INTO v_bruto FROM pagos WHERE mes = p_mes;
  SELECT count(*) INTO v_pagaron FROM pagos WHERE mes = p_mes AND pagado = true;
  SELECT count(*) INTO v_no_pagaron FROM pagos WHERE mes = p_mes AND pagado = false;

  SELECT COALESCE(json_agg(json_build_object(
    'docente_id', d.id,
    'nombre', d.nombre,
    'horas_semana', COALESCE(gh.total_hs, 0)
  )), '[]')
  INTO v_docentes
  FROM docentes d
  LEFT JOIN (
    SELECT g.docente_id, SUM(g.horas_semanales) as total_hs
    FROM grupos g WHERE g.activo = true
    GROUP BY g.docente_id
  ) gh ON gh.docente_id = d.id
  WHERE d.es_owner = false AND d.activo = true;

  INSERT INTO snapshots_mensuales (mes, alumnos_activos, alumnos_nuevos, bajas, facturacion_bruta, costo_docentes, ganancia_neta, pagaron, no_pagaron, detalle_docentes)
  VALUES (p_mes, v_activos, v_altas, v_bajas, v_bruto, 0, v_bruto, v_pagaron, v_no_pagaron, v_docentes)
  ON CONFLICT (mes) DO UPDATE SET
    alumnos_activos = EXCLUDED.alumnos_activos,
    alumnos_nuevos = EXCLUDED.alumnos_nuevos,
    bajas = EXCLUDED.bajas,
    facturacion_bruta = EXCLUDED.facturacion_bruta,
    pagaron = EXCLUDED.pagaron,
    no_pagaron = EXCLUDED.no_pagaron,
    detalle_docentes = EXCLUDED.detalle_docentes;
END;
$$ LANGUAGE plpgsql;


-- ══════════════════════════════════════════════════════════════
-- INDEXES para performance
-- ══════════════════════════════════════════════════════════════

CREATE INDEX idx_alumnos_estado ON alumnos(estado);
CREATE INDEX idx_alumnos_docente ON alumnos(docente_id);
CREATE INDEX idx_alumnos_grupo ON alumnos(grupo_id);
CREATE INDEX idx_pagos_mes ON pagos(mes);
CREATE INDEX idx_pagos_alumno ON pagos(alumno_id);
CREATE INDEX idx_movimientos_mes ON movimientos(mes);
CREATE INDEX idx_contactos_estado ON contactos(estado);
CREATE INDEX idx_mensajes_contacto ON mensajes(contacto_id);
CREATE INDEX idx_grupo_horarios_grupo ON grupo_horarios(grupo_id);
CREATE INDEX idx_disponibilidad_docente ON disponibilidad(docente_id);


-- ══════════════════════════════════════════════════════════════
-- ROW LEVEL SECURITY (básico para producción)
-- ══════════════════════════════════════════════════════════════

ALTER TABLE docentes ENABLE ROW LEVEL SECURITY;
ALTER TABLE tarifas ENABLE ROW LEVEL SECURITY;
ALTER TABLE disponibilidad ENABLE ROW LEVEL SECURITY;
ALTER TABLE grupos ENABLE ROW LEVEL SECURITY;
ALTER TABLE grupo_horarios ENABLE ROW LEVEL SECURITY;
ALTER TABLE alumnos ENABLE ROW LEVEL SECURITY;
ALTER TABLE pagos ENABLE ROW LEVEL SECURITY;
ALTER TABLE movimientos ENABLE ROW LEVEL SECURITY;
ALTER TABLE snapshots_mensuales ENABLE ROW LEVEL SECURITY;
ALTER TABLE contactos ENABLE ROW LEVEL SECURITY;
ALTER TABLE mensajes ENABLE ROW LEVEL SECURITY;
ALTER TABLE seguimientos ENABLE ROW LEVEL SECURITY;

-- Política permisiva para usuario autenticado (vos)
-- En producción se limita por user_id
CREATE POLICY "allow_all" ON docentes FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "allow_all" ON tarifas FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "allow_all" ON disponibilidad FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "allow_all" ON grupos FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "allow_all" ON grupo_horarios FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "allow_all" ON alumnos FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "allow_all" ON pagos FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "allow_all" ON movimientos FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "allow_all" ON snapshots_mensuales FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "allow_all" ON contactos FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "allow_all" ON mensajes FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "allow_all" ON seguimientos FOR ALL USING (true) WITH CHECK (true);


-- ══════════════════════════════════════════════════════════════
-- SEED DATA: Docentes + Tarifas + Disponibilidad
-- ══════════════════════════════════════════════════════════════

INSERT INTO docentes (nombre, es_owner) VALUES
  ('Thiago', true),
  ('Gianella', false),
  ('Nacho', false),
  ('Morena', false);

-- Tarifas Gianella (id=2)
INSERT INTO tarifas (docente_id, min_alumnos, max_alumnos, valor_hora) VALUES
  (2, 1, 2, 7500), (2, 3, 5, 10000), (2, 6, 99, 12000);
-- Tarifas Nacho (id=3)
INSERT INTO tarifas (docente_id, min_alumnos, max_alumnos, valor_hora) VALUES
  (3, 1, 1, 6000), (3, 2, 2, 7500), (3, 3, 99, 8200);
-- Tarifas Morena (id=4)
INSERT INTO tarifas (docente_id, min_alumnos, max_alumnos, valor_hora) VALUES
  (4, 1, 1, 5000), (4, 2, 2, 6000), (4, 3, 99, 8500);

-- Disponibilidad Gianella: Mar/Jue 15-21, Vie 16-21, Sab 9-15
INSERT INTO disponibilidad (docente_id, dia, hora, disponible)
SELECT 2, dia, hora, true FROM (
  SELECT unnest(ARRAY['Martes','Jueves']) as dia, unnest(ARRAY['15:00','16:00','17:00','18:00','19:00','20:00']) as hora
  UNION ALL
  SELECT 'Viernes', unnest(ARRAY['16:00','17:00','18:00','19:00','20:00'])
  UNION ALL
  SELECT 'Sábado', unnest(ARRAY['9:00','10:00','11:00','12:00','13:00','14:00'])
) x;

-- Disponibilidad Nacho: Mar/Mie 9-16, Vie 9-21, Sab 9-11 y 17-21
INSERT INTO disponibilidad (docente_id, dia, hora, disponible)
SELECT 3, dia, hora, true FROM (
  SELECT unnest(ARRAY['Martes','Miércoles']) as dia, unnest(ARRAY['9:00','10:00','11:00','12:00','13:00','14:00','15:00']) as hora
  UNION ALL
  SELECT 'Viernes', unnest(ARRAY['9:00','10:00','11:00','12:00','13:00','14:00','15:00','16:00','17:00','18:00','19:00','20:00'])
  UNION ALL
  SELECT 'Sábado', unnest(ARRAY['9:00','10:00','17:00','18:00','19:00','20:00'])
) x;

-- Disponibilidad Morena: Lun-Vie 17-21
INSERT INTO disponibilidad (docente_id, dia, hora, disponible)
SELECT 4, dia, hora, true FROM (
  SELECT unnest(ARRAY['Lunes','Martes','Miércoles','Jueves','Viernes']) as dia,
         unnest(ARRAY['17:00','18:00','19:00','20:00']) as hora
) x;
